-module(un1).

-export([t/0]).

%% @doc F�pp
t() ->
    �rlig.
